<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<center>
		<a href="registration.php"><button>Registration</button></a></br></br></br></br></br>
		<a href="showInfo.php"><button>Show Registration Info</button></a>
		
	</center>
</body>
</html>