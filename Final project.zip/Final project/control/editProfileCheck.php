<?php
 
 include('../model/db.php');

 global $message;
 $id = $_SESSION["userID"];
 $error="";
 $Error="";

 $connection = new db();
 $conobj=$connection->OpenCon();

 $sql = db::checkOwnProfile($conobj,$id);


global $row;
$row = mysqli_fetch_array($sql);
;



  if (isset($_POST['submit'])) {
	  
	  
	  
	  
	  
	  
if(empty($_POST['mname']) || empty($_POST['memail']) ||  empty($_POST['gender']) || empty($_POST['date']))
	
	{
	 
	 $Error="fields  are empty";
 
	}
	






else{
	 
		$name = $_POST['mname'];
		$email = $_POST['memail'];
		$dob = $_POST['date'];
		$sql = db::updateOwnProfile($conobj,$id,$name,$email, $_POST['gender'],$dob);
		
		
		if ($sql === TRUE) {
		header('Location:../view/profile.php');
		} else {
		echo "Error updating record: " ;
		}

	
   
}


  }
  

	

?>