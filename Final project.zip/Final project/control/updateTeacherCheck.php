<?php
 
//include('../model/db.php');

 $error="";
 $Error="";


  if (isset($_POST['submit'])) {
	  
	  
if(empty($_POST['mname']) || empty($_POST['memail']) ||  empty($_POST['gender']) || empty($_POST['date']))
	
	{
	 
	 $Error="fields  are empty";
 
	}
	
else{
		
		$name = $_POST['mname'];
		$email = $_POST['memail'];
		$dob = $_POST['date'];
		///echo $id;
		$sql = db::updateOfficeProfile($conobj,$id,$name,$email, $_POST['gender'],$dob);
		
		
		if ($sql === TRUE) {
		header('Location:../view/showTeachersInfo.php');
		} else {
		echo "Error updating record: " ;
		}

	
   
}


  }
  

	

?>