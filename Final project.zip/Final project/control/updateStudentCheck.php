<?php
 
//include('../model/db.php');

 $error="";
 $Error="";


  if (isset($_POST['submit'])) {
	  
	  
if(empty($_POST['mname']) || empty($_POST['memail']) ||  empty($_POST['gender']) || empty($_POST['date']) || empty($_POST['phone']))
	
	{
	 
	 $Error="fields  are empty";
 
	}
	
else{
		
		$name = $_POST['mname'];
		$email = $_POST['memail'];
		$dob = $_POST['date'];
		$phone = $_POST['phone'];
		///echo $id;
		$sql = db::updateStudentProfile($conobj,$id,$name,$email, $_POST['gender'],$dob,$phone);
		
		
		if ($sql === TRUE) {
		header('Location:../view/showStudents.php');
		} else {
		echo "Error updating record: " ;
		}

	
   
}


  }
  

	

?>