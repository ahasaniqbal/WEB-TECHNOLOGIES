<?php
include('../model/db.php');
$success="";
$error="";
 
$matchPass="";
if (isset($_POST['submit'])) {
		  
if (empty($_POST['catagory']) || empty($_POST['text'])){
$error = "Fill up All the Field For Successfull Registration";
 
}

  
  else
{
		  
		 $text = $_POST["text"];
		
		
		$connection = new db();
		$conobj=$connection->OpenCon();

		$sll =  db::insertNotice($conobj,$_POST["catagory"],$text);
		
		$se =$conobj->query($sll);
		
		if($se){
		$success = "Succefully posted notice";

		 
		
        }
     
		}
		
}
		?>