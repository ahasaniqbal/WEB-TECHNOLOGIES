<?php

session_start();

if(session_destroy())
{
setcookie("userName","", time() - (86400 * 50), "/"); 
header("Location: ../view/login.php");
}

?>