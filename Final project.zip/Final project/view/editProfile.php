<?php
$radio1="";
$radio2="";
$radio3="";

include('portal.php');

//include('../control/editProfileValidation.php');
include('../control/editProfileCheck.php');
global $date;
$date = $row['dob'];


?>
<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>School Management System</title>
		<script type="text/javascript">
			function validated()
			{
				var name = document.getElementById("name").value;
				var em = document.getElementById("email").value;
				var dob = document.getElementById("date").value;
	
				if(name=="")
				{
					alert("empty name field");
					return false;
				}
				else{
					var regName = /^[A-Za-z]+ [A-Za-z]+$/;
					if(!regName.test(name)){
						 alert('Please enter valid Name');
						 return false;
					}
				}
				if(em == "")
					{
				alert("empty email field");

				return false;
				}
				if(em != ""){
		
				var regEm = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
				if(!regEm.test(em)){
				alert("You have entered an invalid email address!");
				return false;

				}
				}
				if(dob=="")
					{
			       alert("give your date of birth");
				   return false;
					}
						}
						
	
  
		</script>
		
	</head>
	<body>
	
	<center>
	
		<div>
		  <form action="" method="post" onsubmit="return validated()">
			<table class="profileedit_wrap">					
				<tr>
					<td>Name:</td>
					<td></td>
					<td><input type ="text" name = "mname" id="name" method ="post" value="<?php if(isset($row['name']))
					{echo $row['name'];}?>"></td>
					
				</tr>
				<tr><td colspan="3"><hr></td></tr>
				<tr>
					<td>Email:</td>
					<td></td>
					<td><input type ="email" name ="memail" id="email" method ="post"  value="<?php echo $row['email'];?>"></td>
					
				</tr>
				<tr><td colspan="3"><hr></td></tr>
				<tr>
					<td>Gender:</td>
					<td></td>
					<td>
					<?php 

					  if($row["gender"]=="Male")
					  {
						  $radio1="checked";
					  }
					else  if($row["gender"]=="Female")
					  {
						  $radio2="checked";
					  }
					  else{
						  $radio3="checked";
					  }
					
					
				echo 	"<input type='radio' value='Male' name='gender' id='Male' $radio1/>Male
						 <input type='radio' value='Female' name='gender' id='Female' $radio2 />Female
						 <input type='radio' value='Others' name='gender' id='Others' $radio3 />Others</td>
					<td></td>";
					?>
				</tr>
				<tr><td colspan="3"><hr></td></tr>
				<tr>
					<td>Date Of Birth:</td>
					<td></td>
					<td><input type ="text" name ="date" id="date" method ="post"  value=" <?php echo $date ?>"></td>
			  
				</tr>
				<tr><td colspan="3"><hr></td></tr>
				<tr>
					<td><input type ="submit" value ="Update" name="submit"></td>
					<td></td>
					
				</tr>
									
			</table>					
		</form>	
		</div>
	 </center>
	</body>
</html>