<?php
include('portal.php');
include ('../model/db.php');

//session_start();

$connection = new db();
$conobj=$connection->OpenCon();

$sql = "SELECT * FROM teachersdetails";
$result = $conobj->query($sql);
$connection->CloseCon($conobj);

 

?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<center>
	<table border=1 cellspacing="0" class="table_wrap">
		<thead class="table_head">
			<th>UserId</th>
			<th>Name</th>
			<th>Email</th>
			<th>Gender</th>
			<th>Department</th>
			<th>Action</th>
		</thead>
		 <tbody >    
			
				<?php
					if ($result->num_rows > 0) {
		
				while($row = $result->fetch_assoc()) {
			  
			 echo "<tr>";
			echo "<td>$row[userId]</td> 
				  <td>$row[Name]
				  <td>$row[email]</td>
				  <td>$row[gender]</td>
				  <td>$row[department]</td>
				  <td id=action><a href=updateTeacher.php?id=$row[userId]><button>Update</a></button> <a href=../control/deleteTeacherCheck.php?id=$row[userId]><button>Delete<button></a><br></td>";
			echo "</tr>";
			
			}
			
				}
				?>
			
		</tbody>
	</table>
	</center>
</body>
</html>