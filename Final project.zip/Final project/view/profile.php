<?php
	include('portal.php');
	$id = $_SESSION["userID"];
	include('../model/db.php');

	//include('../control/profileCheck.php');
	$connection = new db();
    $conobj=$connection->OpenCon();
	$query = "SELECT * FROM `officeinfo` WHERE `userId` = '$id'";
    $result = $conobj->query($query);
    $row = mysqli_fetch_array($result);
	$name =$row['name'];
	$email =$row['email'];
	$gender =$row['gender'];
	$dob =$row['dob'];
	$connection->CloseCon($conobj);
	
?> 

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	
	<center>
		<table>
			<tr>
			<td width ="1200px" height ="700px">
		
				   	
					<table class="profile_wrap" align="center">
						<tr>
							<td><h2>Profile</h2></td>
							<td></td>
							<td>
							</td>
						</tr>
						<tr>
							<td>User Id:</td>
							<td><?php $userid =$_SESSION["userID"];
									echo $userid;
							?></td>
							<td></td>
						</tr>
						<tr>
							<td colspan="3"><hr></td>
						</tr>
						<tr>
							<td>Name:</td>
							<td><?php
							echo $name;?></td>
							<td></td>
						</tr>
						<tr>
							<td colspan="3"><hr></td>
						</tr>
						<tr>
							<td>Email:</td>
							<td><?php if(isset($email)){
							echo $email;}?></td>
							<td></td>
						</tr>
						<tr>
							<td colspan="3"><hr></td>
						</tr>
						<tr>
							<td>Gender:</td>
							<td><?php echo $gender; ?></td>
							<td></td>
						</tr>
						<tr>
							<td colspan="3"><hr></td>
						</tr>
						<tr>
							<td>Date Of Birth:</td>
							<td><?php echo $dob;?></td>
							<td></td>
						</tr>
		</table>
	</center>
</body>
</html>


