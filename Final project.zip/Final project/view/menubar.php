<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<link rel="stylesheet" href="../css/menubar.css" />
<body>
<div class="menubar_class">
	<ul id="menu">
		<li><a href="menubar.php">Home</a></li>
		<li><a href="login.php">Login</a></li>
	</ul>
</div>
</body>
</html>