<?php
$radio1="";
$radio2="";
$radio3="";

include('portal.php');
include('../model/db.php');

$id = $_GET["id"];
$connection = new db();
$conobj=$connection->OpenCon();
$sql = db::studentDataRetrieve($conobj,$id);
$result = $conobj->query($sql);
$row = mysqli_fetch_array($result);

include('../control/updateStudentCheck.php');




?>
<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>School Management System</title>
		
	</head>
	<body>
	
	<center>
	
		<div>
		  <form action="" method="post">
			<table class="profileedit_wrap">					
				<tr>
					<td>Name:</td>
					<td></td>
					<td><input type ="text" name = "mname" method ="post" value="<?php if(isset($row['name']))
					{echo $row['name'];}?>"></td>
					
				</tr>
				<tr><td colspan="3"><hr></td></tr>
				<tr>
					<td>Email:</td>
					<td></td>
					<td><input type ="email" name ="memail" method ="post"  value="<?php echo $row['email'];?>"></td>
					
				</tr>
				<tr><td colspan="3"><hr></td></tr>
				<tr>
					<td>Gender:</td>
					<td></td>
					<td>
					<?php 

					  if($row["gender"]=="Male")
					  {
						  $radio1="checked";
					  }
					else  if($row["gender"]=="Female")
					  {
						  $radio2="checked";
					  }
					  else{
						  $radio3="checked";
					  }
					
					
				echo 	"<input type='radio' value='Male' name='gender' $radio1/>Male
						 <input type='radio' value='Female' name='gender' $radio2 />Female
						 <input type='radio' value='Others' name='gender' $radio3 />Others</td>
					<td></td>";
					?>
				</tr>
				<tr><td colspan="3"><hr></td></tr>
				<tr>
					<td>Address</td>
					<td></td>
					<td><input type ="text" name ="date" method ="post"  value=" <?php echo $row['address'] ?>"></td>
			  
				</tr>
				<tr>
					<td>Phone</td>
					<td></td>
					<td><input type ="text" name ="phone" method ="post"  value=" <?php echo $row['phone'] ?>"></td>
			  
				</tr>
				<tr><td colspan="3"><hr></td></tr>
				<tr>
					<td><input type ="submit" value ="Update" name="submit"></td>
					<td></td>
					
				</tr>
									
			</table>					
		</form>	
		</div>
	 </center>
	</body>
</html>