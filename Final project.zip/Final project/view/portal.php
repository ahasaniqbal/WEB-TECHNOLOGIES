<?php
session_start();
if(empty($_SESSION["userID"])) 
{
header("Location:login.php");
}

	

?>


<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<link rel="stylesheet" href="../css/profilehome.css" />
<body>
<div class="menubar_class">
	
	
	<ul id="menu">
		<li><a href="profile.php">Profile</a></li>
		<li><a href="editprofile.php">Edit Profile</a></li>
		<li><a href="manageTeachers.php">Manage Teachers</a></li>
		<li><a href="showStudents.php">Manage Students</a></li>
		<li><a href="notice.php">Notice</a></li>
		<li><a href="../control/logout.php">Logout</a></li> 
	</ul>
	<div class="session_id">
	<center>
	<h1>
	<?php
	if(isset($_COOKIE["userName"]))
	{
		echo $_COOKIE["userName"];
	}
	echo "<br>";
	echo "User ID:";
	//echo "<br>";
    echo	$_SESSION['userID'];?>
	</h1>
	</center>
	</div>
    </div>


 
	</h1>
</body>
</html>