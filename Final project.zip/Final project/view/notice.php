<?php

include('portal.php');
include('../control/noticeCheck.php');


?>
<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>School Management System</title>
		<script>
			function validatednotice(){
				var text = document.getElementById("text").value;
				if(text=="")
				{
					alert("Empty Field");
				}
				
				if (document.getElementById("tc").selected == false &&  document.getElementById("st").selected == false )
				  {
					alert("Select  notice catagory");
					return false;
				  }
			}
		</script>
		
	</head>
	<body>
	
	<center>
	
		<div>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		<br>
		  <form action="" method="post" onsubmit="validatednotice()">
			<select name="catagory" >
			    <option value="" >select notice catagory</option>
			    <option value="Teacher" id="tc">Teacher</option>
				<option value="Student" id="st">Students</option>
			</select>
			<textarea name="text" id="text" cols="50" rows="10"></textarea>	
           <input type="submit" name="submit" value="POST" />			
		</form>	
		</div>
	 </center>
	</body>
</html>