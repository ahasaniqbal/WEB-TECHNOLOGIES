<?php

include('menubar.php');

include('../control/logincheck.php');

if(isset($_SESSION['userID'])){
header('location:portal.php');
}

?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
	<link rel="stylesheet" href="../css/log.css" />
	<script type="text/javascript" src="../js/logvalidated.js"></script>
</head>

<body>
	<br><br>
	<div class="login_page">
		<div class="form">
			<form action="" method="post" class="loginform" onsubmit="logvalidateForm()">
				
				<h2>Login</h2>
				<input  type="text" name="userID" placeholder="user Id" id="id"/><br>
				<input type="password"  name="password" placeholder="password" id="password" />
		  	<?php echo $error;?>
			<hr>
			<input id="submit" type="submit" name="submit" value="LOGIN" />
			
			
			</form>
		</div>
	</div>
</body>

</html>