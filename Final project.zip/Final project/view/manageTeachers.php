<?php 
include('portal.php');


?>


<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
 <center>
	<table class="manage" cellspacing="0" height="500px" cellspacing="0" border="1" width="500px" height="500px" align="center">
	<tr>	
		<td height="400px"  align="center">
		<div id="welcome_reader">Welcome to Teachers Information</div>
	<!--	<a href="showReaderInfo.php"><input type="button" name="button" value="Reader Details" /></a></br><br>-->
		<a href="showTeachersInfo.php"><button id="buttono">Teacher Details</a></button></br><br>
		
	<!--	<a href="readerLoginInfo.php"><input type="button" name="button" value="Reader Login Data"/></a>  -->
		
		</td>
	</tr>
 </table>
 </center>
</body>
</html>