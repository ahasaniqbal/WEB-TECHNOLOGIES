<?php
class db{
 
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "school";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
 
 return $conn;
 }

 
 function CheckOfficeUser($conn,$table, $userId, $password)
 {
$sql = $conn->query("SELECT * FROM ". $table." WHERE userId ='". $userId."' AND password='". $password."'");
 return $sql;
 }
 

 
 
function UserInfoTable($conn, $userId,$name,$email,$gender,$phone,$bloodGroup,$dob)
 
{
$flag=1;

$stmt = $conn->prepare("INSERT INTO readerregistrationinfo (userId, name, email, gender,phone,bloodGroup,dob) VALUES (?, ?, ?, ?, ?, ?, ?)");


$stmt->bind_param("sssssss", $userId, $name, $email, $gender, $phone, $bloodGroup,$dob);

$stmt->execute();
$stmt->close();

return $flag;
 }
 

 
 

 function ShowInfoEmployees($conn,$table,$userId)
 {
$sql = $conn->query("SELECT * FROM ". $table." WHERE userId ='". $userId."' ");
 return $sql;
 }
 
function insertNotice($conn,$catagory, $text){
	 
$flag=1;

$stmt = $conn->prepare("INSERT INTO notice (catagory,notice) VALUES (?, ?)");


$stmt->bind_param("ss", $catagory, $text);

$stmt->execute();
$stmt->close();

return $flag;


 }

 
 function updateOfficeInfo($conn,$id, $name, $email,$gender,$address,$joiningDate, $phone, $bloodGroup,$dob)
 {
	 
	$sql = $conn->query( "UPDATE officeinfo set name='". $name."', email='". $email."',gender='". $gender."',address='". $address."',joiningDate='". $joiningDate."', phone='". $phone."', bloodGroup='". $bloodGroup."',dob='". $dob."' WHERE userId='". $id ."'");
	
	 return $sql;
	 
 }
 
 function checkOwnProfile($conn,$id)
 
 {
	 $result = $conn->query("SELECT * from officeinfo WHERE userId='" . $id."'");
	 return $result;
 }
 function updateOwnProfile($conn,$id,$name,$email,$gender,$dob)
 
 {
	$sql = $conn->query( "UPDATE officeinfo set name='". $name."', email='". $email."',gender='". $gender."',dob='". $dob."' WHERE userId='". $id ."'"); 
	return $sql;
 }
 function OfficeDataRetrieve($conn, $ID)
 
 {
	 $sql = "SELECT * FROM teachersdetails where userId = '" . $ID."'";
	 return $sql;
 }
  function studentDataRetrieve($conn, $ID)
 
 {
	 $sql = "SELECT * FROM studentdetails where userId = '" . $ID."'";
	 return $sql;
 }
  function updateOfficeProfile($conn,$id,$name,$email,$gender,$dob)
 
 {
	$sql = $conn->query( "UPDATE teachersdetails set name='". $name."', email='". $email."',gender='". $gender."',department='". $dob."' WHERE userId='". $id ."'"); 
	return $sql;
 }
 function updateStudentProfile($conn,$id,$name,$email,$gender,$dob,$phone)
 
 {
	$sql = $conn->query( "UPDATE studentdetails set name='". $name."', email='". $email."',gender='". $gender."',address='". $dob."',phone='". $phone."' WHERE userId='". $id ."'"); 
	return $sql;
 }
 
 function deleteTeacherInfo($conn,$id)
 
 {
	 $sql = $conn->query("DELETE FROM teachersdetails WHERE userId= '".$id."'");
	 return $sql;

 }
  function deleteStudentInfo($conn,$id)
 
 {
	 $sql = $conn->query("DELETE FROM studentdetails WHERE userId= '".$id."'");
	 return $sql;

 }
 function deleteOfficeLoginInfo($conn,$id)
 
 {
	 $sql1 = $conn->query("DELETE FROM officelogin WHERE userId= '".$id."'");
	 return $sql1;

 }
 
 function CloseCon($conn)
 {
 $conn -> close();
 }

 }
?>

