<html>
	<head></head>
	<body>
	<center>
		<table border="1" cellspacing="0" height="400px" width="600px">
			<tr>
			    <th>Student Id</th>
				<th>Student Name</th>
				<th>Email</th>
				<th>Address</th>
			</tr>
			<tr>
				<th>16-23787-3</th>
				<th>Dipto Mondol</th>
				<th>dipto@gmail.com</th>
				<th>Nakhalpara</th>
			</tr>
			<tr>
				<th>16-5498-3</th>
				<th>Tithi Goash</th>
				<th>thithi@gmail.com</th>
				<th>Khilkhet</th>
			</tr>
			<tr>
				<th>15-47338-1</th>
				<th>Bulbul Ahmed</th>
				<th>bulbul909@gmail.com</th>
				<th>Nikunja-1</th>
			</tr>
			<tr>
				<th><input type="button" value="Create" /></th>
				<th><input type="button" value="Update" /></th>
				<th><input type="button" value="Delete" /></th>
				
			</tr>

		</table>
	</center>
	</body>
</html>