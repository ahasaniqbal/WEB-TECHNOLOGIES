<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<center>
 <textarea name="" id="" cols="30" rows="10" placeholder="write notice for all teachers"></textarea>
 <input type="button" value="send"/>
</center>	
</body>
</html>