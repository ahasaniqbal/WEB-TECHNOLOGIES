<!DOCTYPE HTML>
<html lang="en-US">
	<head>
		<meta charset="UTF-8">
		<title>News Portal Management System</title>
	</head>
	<body background ="">
		<div>
			<table border="1">	
					</tr>
						<td colspan ="2" width ="100%" height="50px" align="center">
						<h1>
							<?php
								if(isset($_COOKIE["name"]))
								{
									
									echo "welcome to " .$_COOKIE["name"] ." " ."in your Profile";
								}
							?>
						</h1>
						</td>
					</tr>
					</tr>
						<td height ="400"><b align="left"><h1>Account</h1></b>
							<hr>
							<ul>
								<li><a href="showTeachersInfo.php"><h3>Manage Teacher</h3></a></li>
								<li><a href="course.php"><h3>Manage Courses</h3></a></li>
								<li><a href="departments.php"><h3>Manage Departments</h3></a></li>
								<li><a href="student.php"><h3>Manage Students</h3></a></li>
								<li><a href="salary.php"><h3>Manage Salary</h3></a></li>
								<li><a href="studentPayments.php"><h3>Manage Student Payments</h3></a></li>
								<li><a href="../control/logout.php"><h3>logout</h3></a></li>
							</ul>
							<td width ="1200px" height ="700px"></td>
						</td>
					</tr>
					<tr>
						<td colspan="2" align="center"><h4>Copyright from @glaxoserfr4.com<h4></td>
					</tr>
			</table>
			</div>
					
			
	</body>
</html>