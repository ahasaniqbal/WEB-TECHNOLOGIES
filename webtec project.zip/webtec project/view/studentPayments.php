<html>
	<head></head>
	<body>
	<center>
		<table border="1" cellspacing="0" height="400px" width="600px">
			<tr>
			    <th>User Id</th>
				<th>Student's Name</th>
				<th>Pending Payments</th>
				<th>Payments</th>
				<th>Total Payments</th>
			</tr>
			<tr>
				<th>17-9399-2</th>
				<th>Mahbub Ahmed</th>
				<th>60,000/=</th>
				<th>90,000</th>
				<th>150,000</th>
			</tr>
			<tr>
				<th>17-34984-3</th>
				<th>Kamal Tapadar</th>
				<th>20,000/=</th>
				<th>80,000</th>
				<th>10,0000</th>
			</tr>
			<tr>
				<th>17-47338-1</th>
				<th>Shikha Akter</th>
				<th>0</th>
				<th>1,20,000</th>
				<th>1,20,000</th>
			</tr>
			<tr>
				<th><input type="button" value="Create" /></th>
				<th><input type="button" value="Update" /></th>
				<th><input type="button" value="Delete" /></th>
				
			</tr>

		</table>
	</center>
	</body>
</html>