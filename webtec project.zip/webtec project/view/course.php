<html>
	<head></head>
	<body>
	<center>
		<table border="1" cellspacing="0" height="400px" width="600px">
			<tr>
				<th>CSE</th>
				<th>EEE</th>
				<th>BBA</th>
				<th>Mechanical</th>
				<th>IPE</th>
			</tr>
			<tr>
				<th>Programming Language-1</th>
				<th>Introduction to electrical circuit</th>
				<th>Society stude</th>
				<th>Logical Design</th>
				<th>Organic Chemistry</th>
			</tr>
			<tr>
				<th>Mathemetics 1</th>
				<th>Ac</th>
				<th>Politics study</th>
				<th>Vision Design and Pattern</th>
				<th>Desgin and Drawing</th>
			</tr>
			<tr>
				<th>Physics 1</th>
				<th>DC</th>
				<th>Buseness study</th>
				<th>Environmental Science</th>
				<th>Chemistry-2</th>
			</tr>
			<tr>
				<th><input type="button" value="Create" /></th>
				<th><input type="button" value="Update" /></th>
				<th><input type="button" value="Delete" /></th>
				
			</tr>

		</table>
	</center>
	</body>
</html>