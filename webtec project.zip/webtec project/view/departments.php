<html>
	<head></head>
	<body>
	<center>
		<table border="1" cellspacing="0" height="400px" width="600px">
			<tr>
			    <th>User Id</th>
				<th>Department Name</th>
				<th>Course Teacher Name</th>
				<th>Title</th>
			</tr>
			<tr>
				<th>17-9399-2</th>
				<th>CSE</th>
				<th>Mahbubl Sayeed</th>
				<th>Department Head</th>
			</tr>
			<tr>
				<th>17-34984-3</th>
				<th>CSE</th>
				<th>Dr. Dip Nandi</th>
				<th>Director of Cs Engineering</th>
			</tr>
			<tr>
				<th>17-47338-1</th>
				<th>EEE</th>
				<th>Kamal Pasha</th>
				<th>Associate Professor</th>
			</tr>
			<tr>
				<th><input type="button" value="Create" /></th>
				<th><input type="button" value="Update" /></th>
				<th><input type="button" value="Delete" /></th>
				
				
			</tr>

		</table>
	</center>
	</body>
</html>