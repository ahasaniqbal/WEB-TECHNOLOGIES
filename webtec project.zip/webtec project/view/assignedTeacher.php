<?php
	include('../control/assignedTeacherCheck.php');
	session_start();
	
		
		
    if(isset($_REQUEST['submit'])){	
	
		
        if(!empty($_REQUEST['id']) && !empty($_REQUEST['cname']) && !empty($_REQUEST['ctname']) && !empty($_REQUEST['rmno'])){
			
			
            $info = $_REQUEST['id']."|". $_REQUEST['cname']."|".$_REQUEST['ctname']."|".$_REQUEST['rmno']."\n";
            $myfile = fopen("assignedfile.txt", "a");
            fwrite($myfile, $info);
            fclose($myfile);
            echo "Assigned successfully done!";   
        }
        
		
        else{
            $error = "Check and fill up the all field!";
            
        }
		
    
		
		
	}
?>


<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
<form action="" method="post">
<center>
<fieldset>	
	<table>
	
		<tr>
			<td>Course Id</td>
			<td><input type="text" name="id"/></td>	
		</tr>
		<tr>
			<td>
				<hr />
			</td>
		</tr>
		<tr>
			<td>Course Name</td>
			<td><input type="text" name="cname" /></td>	
		</tr>
		<tr>
			<td>
				<hr />
			</td>
		</tr>
		<tr>
			<td>Course Teacher Name</td>
			<td><input type="text" name="ctname"/></td>	
		</tr>
		<tr>
		<tr>
			<td>
				<hr />
			</td>
		</tr>
			<td>Room No</td>
			<td><input type="text" name="rmno"/></td>	
		</tr>
		<tr>
			<td>
				<hr />
			</td>
		</tr>
		<tr>
			<td><input type="submit" value="Assigned Teacher"  name="submit"/></td>
			<td><input type="reset" value="Reset" /></td>	
		</tr>
		
	</table>
	</fieldset>
</center>
</form>	
</body>
</html>