<html>
	<head></head>
	<body>
	<center>
		<table border="1" cellspacing="0" height="400px" width="600px">
			<tr>
			    <th>User Id</th>
				<th>Department Name</th>
				<th>Teacher Name</th>
				<th>Salary</th>
			</tr>
			<tr>
				<th>17-0000-2</th>
				<th>CSE</th>
				<th>Mahbubl Sayeed</th>
				<th>1,20,0000=/</th>
			</tr>
			<tr>
				<th>17-478758-3</th>
				<th>CSE</th>
				<th>Dr. Dip Nandi</th>
				<th>1,60,0000/=</th>
			</tr>
			<tr>
				<th>17-484578-1</th>
				<th>EEE</th>
				<th>Kamal Pasha</th>
				<th>80,0000/=</th>
			</tr>
			<tr>
				<th><input type="button" value="Create" /></th>
				<th><input type="button" value="Update" /></th>
				<th><input type="button" value="Delete" /></th>
				
			</tr>

		</table>
	</center>
	</body>
</html>