<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	<a href="teacherinfo.php"><input type="button" value="Show Teacher's Details" /></a>
	<a href="noticeTeacher.php"><input type="button" value="Send Notice" /></a>
	<a href="assignedTeacher.php"><input type="button" value="Assigned Teacher" /></a>
</body>
</html>