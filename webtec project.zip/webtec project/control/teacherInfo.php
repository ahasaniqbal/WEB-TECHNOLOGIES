<html>
	<head></head>
	<body>
		<table border="1" cellspacing="0">
			<tr>
				<th>User Id</th>
				<th>Teacher's Name</th>
				<th>Address</th>
				<th>Age</th>
				<th>Date of Birth</th>
			</tr>
			<tr>
				<th>17-34784-3</th>
				<th>Abdur Rob</th>
				<th>Nikunja-2</th>
				<th>45</th>
				<th>11-02-1980</th>
			</tr>
			<tr>
				<th>17-23784-3</th>
				<th>Afruza Nahar</th>
				<th>Gulshan</th>
				<th>51</th>
				<th>10-10-1985</th>
			</tr>
			<tr>
				<th>17-76584-3</th>
				<th>Tareq Khan</th>
				<th>Dhanmondi</th>
				<th>35</th>
				<th>1-9-1989</th>
			</tr>
		</table>

	</body>
</html>