<?php


if(isset($_REQUEST['submit'])){
	$id = $_REQUEST['id'];
	$cname = $_REQUEST['cname'];
	$ctname = $_REQUEST['ctname'];
	$rm = $_REQUEST['rmno'];
	if(empty($id) || empty($cname) || empty($ctname) || empty($rm)){


		header('location: ../view/assignedTeacher.php?msg=null');
	}
	else{
		echo"succssfully assigned done";
	}

}
?>